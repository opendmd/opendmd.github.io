OpenDMD simulator 1.0.0-beta.2, Windows (x86-64)
================================================

Plays GIFs in a window drawn as the LEDs of the 128x32 DMDoS display,
through the same engine the OpenDMD firmware runs.

Start it
--------

Double-click opendmd-sim.exe and choose a folder: a card (a folder with
filelist.txt in it) or any folder of GIFs. Cancel for the built-in demo of
the panel's effects and live items. You can also drop a folder, or a GIF,
onto opendmd-sim.exe. The console window beside it shows what is playing.

From a terminal:

    opendmd-sim <folder or GIF>      a card, any folder of GIFs, or one GIF
    opendmd-sim --demo               the built-in demo
    opendmd-sim --help               every option

Keys: Space next, P pause/resume, L LEDs/flat squares, Esc quit.

The first time
--------------

The simulator isn't code-signed, so Windows SmartScreen may say it
"protected your PC". Click More info, then Run anyway.

More: https://opendmd.github.io/dev/simulator.html

Licence: MIT or Apache-2.0, at your option (LICENSE-MIT.txt,
LICENSE-APACHE.txt). The open-source crates it is built from, and their
licences, are listed in THIRD-PARTY-LICENSES.txt. OpenDMD is an
independent project, not made by or affiliated with DMDoS.
