OpenDMD simulator 1.0.0-beta.2, Linux (x86-64)
==============================================

Plays GIFs in a window drawn as the LEDs of the 128x32 DMDoS display,
through the same engine the OpenDMD firmware runs.

Start it
--------

Run ./opendmd-sim (or double-click it, if your file manager runs
programs) and choose a folder: a card (a folder with filelist.txt in it) or
any folder of GIFs. Cancel for the built-in demo of the panel's effects and
live items.

From a terminal:

    ./opendmd-sim <folder or GIF>      a card, any folder of GIFs, or one GIF
    ./opendmd-sim --demo               the built-in demo
    ./opendmd-sim --help               every option

Keys: Space next, P pause/resume, L LEDs/flat squares, Esc quit.

What it needs
-------------

glibc 2.34 or newer (Ubuntu 22.04, Debian 12, Fedora 35 and later) and an
X11 or Wayland desktop (libX11 and libXcursor, or libwayland-client and
libxkbcommon: every desktop has them). The folder picker is the desktop's
own, through xdg-desktop-portal, or zenity; without either, give the folder
on the command line.

More: https://opendmd.github.io/dev/simulator.html

Licence: MIT or Apache-2.0, at your option (LICENSE-MIT.txt,
LICENSE-APACHE.txt). The open-source crates it is built from, and their
licences, are listed in THIRD-PARTY-LICENSES.txt. OpenDMD is an
independent project, not made by or affiliated with DMDoS.
