OpenDMD simulator 1.0.0-beta.2, macOS (Apple silicon and Intel)
===============================================================

Plays GIFs in a window drawn as the LEDs of the 128x32 DMDoS display,
through the same engine the OpenDMD firmware runs.

Start it
--------

Double-click opendmd-sim. It opens in Terminal, then asks for a
folder: choose a card (a folder with filelist.txt in it) or any folder of
GIFs. Cancel for the built-in demo of the panel's effects and live items.

From a terminal:

    ./opendmd-sim <folder or GIF>      a card, any folder of GIFs, or one GIF
    ./opendmd-sim --demo               the built-in demo
    ./opendmd-sim --help               every option

Keys: Space next, P pause/resume, L LEDs/flat squares, Esc quit.

The first time
--------------

The simulator isn't signed with an Apple developer certificate, so macOS
won't open it with a double-click at first. Control-click (or right-click)
opendmd-sim, choose Open, then Open again. If macOS offers no Open button
(macOS 15 and later), try once, then go to System Settings > Privacy &
Security and click Open Anyway. From a terminal you can instead run:

    xattr -d com.apple.quarantine opendmd-sim

More: https://opendmd.github.io/dev/simulator.html

Licence: MIT or Apache-2.0, at your option (LICENSE-MIT.txt,
LICENSE-APACHE.txt). The open-source crates it is built from, and their
licences, are listed in THIRD-PARTY-LICENSES.txt. OpenDMD is an
independent project, not made by or affiliated with DMDoS.
